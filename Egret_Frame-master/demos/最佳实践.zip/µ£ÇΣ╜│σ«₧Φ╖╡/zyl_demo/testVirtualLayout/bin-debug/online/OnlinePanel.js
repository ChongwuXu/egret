var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/**
  * 在线页面
    * @author Created by peony on 2016/8/4.
    *
    */
var OnlinePanel = (function (_super) {
    __extends(OnlinePanel, _super);
    function OnlinePanel() {
        var _this = _super.call(this) || this;
        /** 在线数据*/
        _this.OnlineListUp = [
            { icon: "icon_general_01_png" }
        ];
        _this.isVis = true;
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.initPanel, _this);
        _this.skinName = "OnlineSkin";
        return _this;
    }
    OnlinePanel.prototype.initPanel = function () {
        this.btnClose.addEventListener(egret.TouchEvent.TOUCH_TAP, this.closePanel, this);
        for (var i = 0; i < 1000; i++) {
            this.OnlineListUp.push({ icon: "icon_general_01_png" });
        }
        this.onlineList.itemRenderer = onlineList;
        this.onlineList.dataProvider = new eui.ArrayCollection(this.OnlineListUp);
        this.onlineList.useVirtualLayout = this.isVis;
        var layout = new eui.VerticalLayout();
        layout.gap = 10;
        layout.paddingLeft = 2;
        this.onlineList.layout = layout;
    };
    OnlinePanel.prototype.initData = function () {
    };
    OnlinePanel.prototype.refresh = function () {
    };
    OnlinePanel.prototype.destory = function () {
        this.btnClose.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.closePanel, this);
    };
    OnlinePanel.prototype.closePanel = function () {
        this.isVis = !this.isVis;
        this.onlineList.useVirtualLayout = !this.isVis;
        var str = this.isVis ? '关闭虚拟布局' : '开启虚拟布局';
        this.textv.text = str;
    };
    return OnlinePanel;
}(eui.Component));
__reflect(OnlinePanel.prototype, "OnlinePanel");
//# sourceMappingURL=OnlinePanel.js.map