var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/**
* @author Created by peony on 2017/2/14.
* @see 在线领取列表
*
*/
var onlineList = (function (_super) {
    __extends(onlineList, _super);
    function onlineList() {
        var _this = _super.call(this) || this;
        _this.skinName = "onlineListSkin";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.show, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.hide, _this);
        return _this;
    }
    onlineList.prototype.show = function () {
        this.btnReceive.addEventListener(egret.TouchEvent.TOUCH_TAP, this.requestHandle, this);
    };
    onlineList.prototype.hide = function () {
        this.btnReceive.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.requestHandle, this);
    };
    onlineList.prototype.refresh = function () {
    };
    /** 数据变化*/
    onlineList.prototype.dataChanged = function () {
        this.onlineRw.source = this.data.icon;
        this.refresh();
    };
    /** 请求处理*/
    onlineList.prototype.requestHandle = function () {
    };
    /** 请求回调*/
    onlineList.prototype.onPostComplete = function (event) {
    };
    return onlineList;
}(eui.ItemRenderer));
__reflect(onlineList.prototype, "onlineList");
//# sourceMappingURL=onlineList.js.map